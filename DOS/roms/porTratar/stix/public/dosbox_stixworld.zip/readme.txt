StixWorld Release Notes - v1.0 (07/27/98)

This text file explains how to install, run, and register StixWorld and
includes troubleshooting information.  If you have trouble installing or
playing StixWorld, look below.


Contents
--------
1) Where to Get the Latest Version
2) How to Register
3) Installation and Super Quick Setup
4) Windows 95/98 Full Setup
5) DOS Full Setup
6) Playing the Game
7) Finding Information about your Sound Card
8) Sound Card Compatibility
9) Solving Common Problems


1) Where to Get the Latest Version
-----------------------------------
To get the latest version and information about StixWorld, visit the
StixWorld Web page at http://www.kagi.com/phs


2) How to Register
------------------
StixWorld is shareware.  You're free to give copies to your friends, or
upload it to a BBS.  However, if you enjoy playing, please register.
You'll be encouraging future shareware software, plus you'll get this nifty
stuff:

     * The key to the StixArcade, with Blast and Robot Chase
     * Great hints and cheats and mysterious secrets

StixWorld registration costs only $15.  To register by credit card on the 
World Wide Web, visit http://www.kagi.com/phs

You can also register by email or snail mail, using either check, credit card,
or money order.  To do so, run Winreg.exe (for Windows) or Register.exe (for
DOS).  These files are located in your StixWorld directory.  


3) Installation and Super Quick Setup
-------------------------------------
   StixWorld has been tested to run on DOS, Windows, Windows 95 and 98, 
   Windows NT, and OS/2.

   To install StixWorld, follow the steps below:

   1.  Create a separate directory (for example, C:\STIX) in which to install
       the game.
   2.  Unzip the file Stix.zip into your new directory, using a utility such 
       as Pkunzip or WinZip.  
   
   You can get StixWorld running quickly in either of the following cases:
   *   You already know which sound card you have and which parameters it
       takes, and the necessary DOS sound card drivers are loaded.
   *   You want to run StixWorld without sound (not recommended!).

   To get it running, perform the following steps:

   1.  Run Config.exe and either select the "No Sound" option or enter the
       necessary information for your sound card.
   2.  Run Stx.exe.

   If you have any problems, see the full setup sections.


4) Windows 95/98 Full Setup
------------------------
You can run StixWorld under two different modes.  The easiest way, described
first, is to run it under Windows 95/98.  If you have problems with that, you 
might want to use MS-DOS mode instead.

   Windows 95/98 Mode
   ---------------
   Running StixWorld under Windows 95/98 is the easiest method, assuming you 
   have enough lower memory available.

   Before running Config.exe, make sure you know what sound card you have and
   which parameters it takes.  For information, see "Finding Information 
   about your Sound Card" later in this Readme file.

   To set up StixWorld to run under Windows 95/98, follow these steps:
   1.  In Explorer, click Config.exe and enter the necessary information.
   2.  Make sure that necessary DOS sound card drivers are loaded in
       autoexec.bat and/or config.sys.
   3.  Click Stx.exe and enjoy.

   If you have any problems with this procedure, see "Solving Common Problems," 
   later in this Readme file.  

   MS-DOS Mode
   -----------
   You might want to use MS-DOS Mode if you have autoexec.bat and config.sys
   files that don't work properly with StixWorld, but you don't want to 
   modify them.  For example, they might not provide enough lower memory, or 
   they might not properly load the DOS drivers for your sound card.  One
   disadvantage of MS-DOS Mode is that the computer automatically reboots to
   switch between Windows 95/98 and DOS when Stixworld starts and ends. 

   Before running Config.exe, make sure you know what sound card you have and
   which parameters it takes.  For information, see "Finding Information 
   about your Sound Card" later in this Readme file.

   To set up StixWorld to run in MS-DOS Mode, follow the steps below:
   1.  In Explorer, click Config.exe and enter the necessary information.
   2.  Right-click the file Stx.exe, and then click Properties.
   3.  Click the Program tab, and then click the Advanced button.
   4.  Select the "MS-DOS mode" check box, and then modify autoexec.bat and
       config.sys as needed.  Make sure that your sound card driver is 
       properly loaded in one of the files.  This creates the file Stx.pif.
   5.  To run StixWorld, double click Stx.pif or Stx.exe.


5) DOS Full Setup
-----------------
Before running Config.exe, make sure you know what sound card you have and
which parameters it takes.  For information, see "Finding Information about
your Sound Card" later in this Readme file.

To set up StixWorld to run under DOS, follow these steps:
1. Run Config.exe and enter the necessary information.
2. Make sure that necessary DOS sound card drivers are loaded in autoexec.bat
   and/or config.sys.
3. Run Stx and enjoy.

If you have any problems with this procedure, see "Troubleshooting," later in
this Readme file.  


6) Playing the Game
----------------
The controls in the game are as follows:

Movement            - Left and right arrows
Jump                - Ctrl key
Enter door/window   - Up arrow
Game menu           - Esc key
Pause               - P
Zoom in             - Page Down
Zoom out            - Page Up


7) Finding Information About Your Sound Card
--------------------------------------------
To run StixWorld with sound (highly recommended!), you need to know what 
sound card you have and what parameters it takes.  If you don't have that 
information but you do have Windows 95, you can find out by following the 
procedure below:

1. In Control Panel, double-click System, and then click the Device Manager
   tab.
2. Click the plus sign next to "Sound, video, and game controllers."  You 
   will see the name of your sound card.
3. Click your sound card, click the Properties button, and then click the
   Resources tab.
4. Write down the Input/Output Range settings.  In the Config program, you
   will use the starting address as your port address.
5. Write down the Interrupt Request setting.  In the Config program, you
   will use it as your IRQ number.
6. Write down the Direct Memory Access setting.  In the Config program, you
   will use it as your DMA channel.

Some sound cards are not listed in StixWorld Config.  If so, see the next
section, "Sound Card Compatibility."


8) Sound Card Compatibility
---------------------------
If your sound card is not listed in StixWorld Config, you can choose a
compatible card.  Most sound cards are compatible with one of the Creative 
Labs SoundBlaster cards listed in StixWorld Config.

However, some sound cards, such as the Gravis Ultrasound, require a software
driver that puts them into SoundBlaster compatibility mode. If you have such 
a card, choose the specific SoundBlaster card with which your card is 
compatible (for example, "SoundBlaster Compatible" or "SoundBlaster Pro"), 
and then make sure the compatibility driver is loaded before you run 
StixWorld.  If your sound card is not compatible with any of the sound cards 
listed, or if you do not have a sound card, you can choose the "No Sound" 
option.  You will be missing out on Scott Joplin's ragtime.

If you choose an incompatible sound card from the list, you might need to 
reboot and run Config again to choose another.  If your card is compatible
with multiple sound cards but one of the Config choices doesn't work, choose
another.

Before running StixWorld, you must make sure that any necessary DOS drivers
for your sound card are loaded.  You cannot use the Windows 95 drivers.  The 
DOS drivers should have come with your sound card, and you can generally 
download them from the sound card manufacturer's Web page, along with
information about modifying the Autoexec.bat and Config.sys files.


9) Solving Common Problems
--------------------------
This section describes common problems that might occur and how to solve them.

   Missing or distorted sound effects or music
   -------------------------------------------
   Make sure the necessary DOS sound card drivers are loaded, and make sure 
   you have selected the correct sound card and parameters in the StixWorld 
   Config program.  For more information, see "Finding Information about Your
   Sound Card" and "Sound Card Compatibility," earlier in this Readme file.

   Computer locks up, reboots, or gives Windows 95 blue screen error
   -----------------------------------------------------------------
   Make sure the necessary DOS sound card drivers are loaded, and make sure 
   you have selected the correct sound card and parameters in the StixWorld 
   Config program.  For more information, see "Finding Information about Your
   Sound Card" and "Sound Card Compatibility," earlier in this Readme file.

   You can also use Chkdsk or Mem to find out how much lower memory you 
   have.  If you have less than 580K of lower memory, freeing up more might 
   solve the problem.  For more information, see the next troubleshooting 
   step.

   StixWorld exits and a Not Enough Memory error message appears
   -------------------------------------------------------------
   The amount of lower memory you will need to run StixWorld depends on 
   which sound card driver you have.  With most sound cards, you need only 
   about 535K available.  Some cards require as much as 560K, and if you 
   choose the "No Sound" option, you need only 460K.  To check the amount
   of memory available, run Mem or Chkdsk.

   To free up memory, you can modify your autoexec.bat and config.sys files 
   to remove unnecessary TSRs and drivers and to load DOS into high memory.  
   For more information, see the Appendix.  If you don't want to modify those
   files, but only want to disable drivers while you are running StixWorld, 
   you can selectively load drivers at boot.  To do so, press and hold down 
   the F8 key when your computer starts.  You will be asked whether you want 
   to run each line of your autoexec.bat and config.sys files.  

   Other Error Messages
   --------------------
   Make sure that the StixWorld directory is the current directory before
   running StixWorld.
   
   Also make sure that your sound card is configured properly.

If you have any futher problems, please visit the StixWorld web page at
http://www.kagi.com/phs


Appendix:  Freeing Up Lower Memory
----------------------------------
Try removing TSR's (such as mouse drivers) from your config.sys and
autoexec.bat files (remember to make backups before changing these
files).

If you have DOS version 5 or above, include the line:

  dos=high

in your config.sys file after "himem.sys" or another memory manager has
been loaded.

For Win95/98, if you are using MSDOS mode, these changes will be made in
the applications properties, int the program tab, under Advanced.
